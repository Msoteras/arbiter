# Handoff: Login de Arbiter (variante 7g)

## Overview

Pantalla de inicio de sesión de **Arbiter**, la plataforma de gestión del ciclo de vida de siniestros del Grupo 5303 (UTN FRBA, Proyecto Final 2026). Es la puerta de entrada de los analistas de la aseguradora: un formulario de correo y contraseña, con enlaces a recuperación de contraseña y solicitud de acceso.

La identidad visual viene del póster del proyecto: papel crema, tipografía Archivo, trazos finos y una cordillera ditherizada a sangre en el borde inferior.

## About the Design Files

Los archivos de este paquete son **referencias de diseño hechas en HTML**: prototipos que muestran el aspecto y el comportamiento buscados, **no código de producción para copiar y pegar**. La tarea es **recrear este diseño dentro del proyecto Angular existente**, con sus patrones, su router, sus servicios y sus convenciones de SCSS. Si algún valor de este README choca con una convención ya establecida del código, gana la convención del código: avisar y documentar la desviación.

`login-7g.html` se abre directo en el navegador y es la fuente de verdad visual. Los assets están en `assets/`.

## Fidelity

**Alta fidelidad (hifi).** Los colores, tipografías, espaciados y tamaños son finales. La UI debería recrearse fiel al píxel en desktop, usando SCSS por componente. Los estados (focus, hover, error, loading) están descritos abajo y deben implementarse aunque no aparezcan en la captura estática.

## Decisión pendiente antes de implementar

El póster del proyecto migró su color de acento a **teal #00A99D**, pero esta pantalla todavía usa el **azul #1e3F8F** heredado de las primeras iteraciones (en focus de inputs, hover del botón y hover de enlaces). Hay que decidir cuál queda:

- **Opción A (recomendada):** unificar con el póster y usar `#00A99D` en los tres lugares. Contraste sobre `#fffdf8`: suficiente para bordes y fondos de botón con texto claro.
- **Opción B:** dejar `#1e3f8f` como color funcional de la app y reservar el teal para material impreso.

Este README documenta los valores **tal como están hoy en el prototipo (azul)**. Si se elige A, reemplazar todas las apariciones de `#1e3f8f` por `#00A99D` y `rgba(30,63,143,0.12)` por `rgba(0,169,157,0.14)`.

## Screens / Views

### Login (única vista)

**Purpose:** el analista se autentica para entrar a Arbiter.

**Layout (desktop, referencia 1440 × 1024):**

- Contenedor raíz: `position: relative`, `overflow: hidden`, fondo `#f4efe4`, alto mínimo `100vh`.
- **Cordillera:** `<img>` posicionada `absolute`, `left: 0; bottom: 0; width: 100%`, `display: block`. Es un PNG con fondo transparente: apoya sobre el crema sin caja ni borde. No recortar ni escalar en alto: el ancho manda y el alto sigue la proporción (757 × 329 → 2,30 : 1).
- **Columna central:** `position: absolute; left: 50%; top: 150px; transform: translateX(-50%)`, ancho fijo `384px`, `display: flex; flex-direction: column; align-items: center; gap: 32px`.
  - En Angular conviene reemplazar el posicionamiento absoluto por un contenedor flex centrado (`justify-content: flex-start`, `padding-top: 150px`), manteniendo el ancho de 384 px de la columna.

**Componentes, de arriba hacia abajo:**

1. **Lockup Arbiter** — `assets/arbiter-lockup.svg`, ancho `190px`, alto automático, `display: block`. Es texto vectorizado; no reemplazar por texto vivo.

2. **Card del formulario**
   - Ancho: `100%` de la columna (384 px). `box-sizing: border-box`.
   - Fondo `#fffdf8`, borde `1px solid #e3dcca`, radio `10px`, padding `28px`.
   - Sombra: `0 1px 2px rgba(27, 26, 23, 0.06)`.
   - Interior: `display: flex; flex-direction: column; gap: 18px`.

3. **Campo Correo**
   - `display: flex; flex-direction: column; gap: 7px`.
   - Etiqueta: `Correo`, 13 px, peso 500, color `#1b1a17`.
   - Input `type="email"`, alto `40px`, borde `1px solid #ded7c6`, radio `6px`, fondo `#fffdf8`, padding lateral `12px`, 14 px, color `#1b1a17`.
   - Placeholder: `analista@aseguradora.com`, color `#a49d8e`.

4. **Campo Contraseña**
   - Misma estructura. La fila de la etiqueta es `display: flex; justify-content: space-between; align-items: baseline`: a la izquierda `Contraseña`, a la derecha el enlace `Olvidé mi contraseña` (13 px, color `#6f6a5e`, sin subrayado).
   - Input `type="password"`, placeholder `••••••••` (ocho U+2022).

5. **Botón Entrar**
   - `margin-top: 4px`, alto `40px`, ancho completo.
   - Fondo `#1b1a17`, texto `#f8f6f0`, sin borde, radio `6px`, 14 px, peso 500, `cursor: pointer`.
   - Texto: `Entrar`.

6. **Enlace Solicitar acceso**
   - Fuera de la card, centrado, 13 px, color `#6f6a5e`, sin subrayado. Separado por el `gap: 32px` de la columna.

## Interactions & Behavior

**Estados visuales**

| Elemento | Estado | Cambio |
|---|---|---|
| Input | `:focus` | `border-color: #1e3f8f` + `box-shadow: 0 0 0 3px rgba(30,63,143,0.12)`. Quitar el outline del navegador. |
| Input | error | `border-color: #b3261e` + mensaje debajo, 12 px, color `#b3261e`, `gap: 6px`. |
| Input | deshabilitado (durante el submit) | `opacity: 0.6`, `pointer-events: none`. |
| Botón | `:hover` | `background: #1e3f8f`. Transición `background 120ms ease`. |
| Botón | `:focus-visible` | `box-shadow: 0 0 0 3px rgba(30,63,143,0.25)`. |
| Botón | loading | Texto `Entrando…`, botón deshabilitado, `cursor: default`. Sin spinner. |
| Enlaces | `:hover` | `color: #1e3f8f` + `text-decoration: underline`. |

**Validación (cliente, antes de llamar a Auth0)**

- Correo: requerido; formato de email válido. Mensaje: `Ingresá un correo válido.`
- Contraseña: requerida. Mensaje: `Ingresá tu contraseña.`
- Validar en `blur` y en el submit, no mientras se tipea.
- El botón `Entrar` permanece habilitado siempre (no deshabilitar por formulario inválido); al hacer submit con errores, se muestran los mensajes y el foco va al primer campo con error.

**Error de autenticación**

Un solo mensaje sobre el botón, dentro de la card, 13 px, color `#b3261e`, sin ícono:
- Credenciales inválidas → `Correo o contraseña incorrectos.`
- Cuenta bloqueada → `Tu cuenta está bloqueada. Contactá al administrador.`
- Error de red o del servidor → `No pudimos conectarnos. Probá de nuevo en unos minutos.`

No revelar si el correo existe o no.

**Navegación**

- Submit correcto → redirigir a la ruta protegida por defecto (bandeja de siniestros).
- `Olvidé mi contraseña` → flujo de recuperación de Auth0.
- `Solicitar acceso` → destino a definir con el equipo (formulario interno o mailto). Dejar el enlace con un `TODO` visible si aún no existe la ruta.

## Autenticación (Auth0)

El alcance pedido es **login real, conectado**. Puntos a resolver en la implementación:

- Usar el SDK oficial `@auth0/auth0-angular` (`AuthModule.forRoot({ domain, clientId, authorizationParams })`), con la configuración leída de `environment.ts` — nunca hardcodeada.
- Esta pantalla es un **formulario propio**, no la Universal Login de Auth0. Dos caminos posibles; elegir uno con el equipo y dejarlo asentado:
  - **Universal Login (recomendado por Auth0):** el botón `Entrar` dispara `loginWithRedirect()` y esta pantalla queda como landing de marca. En ese caso los campos de correo y contraseña sobran y hay que rediseñar la card (avisar antes de implementar).
  - **Login embebido:** requiere habilitar el grant `password` (Resource Owner Password) en el tenant, con las implicancias de seguridad que eso trae. Solo si el equipo ya lo tiene resuelto.
- Guardar el retorno post-login (`appState.target`) para volver a la ruta que el usuario intentaba abrir.
- Proteger las rutas internas con `authGuard` del SDK.
- El token no se guarda a mano: lo administra el SDK.

## State Management

Estado local del componente (`LoginComponent`), sin store global:

| Variable | Tipo | Uso |
|---|---|---|
| `form` | `FormGroup` | Reactive Forms: controles `email` y `password`. |
| `submitting` | `boolean` | Deshabilita inputs y cambia el texto del botón. |
| `authError` | `string \| null` | Mensaje de error de autenticación mostrado sobre el botón. |

Transiciones: `submit` → `submitting = true`, `authError = null` → respuesta → éxito: navegación; fallo: `submitting = false`, `authError = <mensaje>`.

## Responsive

Se pidió **desktop + mobile**, con la cordillera **al pie y la card centrada** también en pantallas chicas.

**Breakpoint único: `768px`.**

Mobile (< 768 px):
- Contenedor: `min-height: 100dvh`, `display: flex`, `flex-direction: column`, `justify-content: center`, `align-items: center`, `padding: 24px`.
- Columna central: ancho `100%`, `max-width: 384px`, `gap: 28px`. Sin `position: absolute` ni `top: 150px`.
- Card: padding `24px`.
- Lockup: `160px` de ancho.
- Cordillera: sigue `absolute; left: 0; bottom: 0; width: 100%`, sin recorte. Como la imagen es panorámica (2,30 : 1), en 390 px de ancho ocupa unos 170 px de alto: es una franja baja y no compite con la card. Reservar ese espacio con `padding-bottom: 200px` en el contenedor para que la card nunca se apoye encima.
- En alturas muy chicas (`max-height: 640px`), ocultar la cordillera (`display: none`) y quitar el `padding-bottom`.
- Altura mínima de los objetivos táctiles: los inputs y el botón pasan de `40px` a **`48px`** en mobile. Los enlaces de 13 px necesitan área táctil de 44 px: agregar `padding: 8px 0` y `margin: -8px 0`.

## Design Tokens

```scss
// Color
$paper:        #f4efe4;  // fondo de pantalla
$surface:      #fffdf8;  // fondo de card e inputs
$ink:          #1b1a17;  // texto principal y fondo del botón
$ink-invert:   #f8f6f0;  // texto sobre el botón
$muted:        #6f6a5e;  // etiquetas secundarias y enlaces
$placeholder:  #a49d8e;
$border-card:  #e3dcca;
$border-input: #ded7c6;
$accent:       #1e3f8f;  // ver "Decisión pendiente": posible cambio a #00A99D
$accent-ring:  rgba(30, 63, 143, 0.12);
$danger:       #b3261e;

// Tipografía — Archivo (Google Fonts), pesos 300/400/500/600/800
$font: 'Archivo', Helvetica, Arial, sans-serif;
// 13px / 500  → etiquetas y enlaces
// 14px / 400  → texto de inputs
// 14px / 500  → botón
// 12px / 400  → mensajes de error

// Espaciado
$gap-column: 32px;  // entre lockup, card y enlace inferior
$gap-card:   18px;  // entre campos dentro de la card
$gap-field:   7px;  // entre etiqueta e input
$pad-card:   28px;  // 24px en mobile

// Formas
$radius-card:  10px;
$radius-field:  6px;
$h-field:      40px;  // 48px en mobile
$w-column:    384px;

// Sombras
$shadow-card:  0 1px 2px rgba(27, 26, 23, 0.06);
$shadow-focus: 0 0 0 3px $accent-ring;
```

## Assets

| Archivo | Qué es | Notas |
|---|---|---|
| `assets/mtn-teal-cutout.png` | Cordillera andina ditherizada (Floyd–Steinberg), fondo recortado | 757 × 329 px, PNG con alfa, 343 KB. Se escala al 100 % del ancho de la ventana; en pantallas anchas se ve interpolada, es el efecto buscado. Va en `src/assets/` y se referencia por URL. |
| `assets/arbiter-lockup.svg` | Lockup Arbiter (símbolo + palabra) en negro | Texto ya vectorizado. Va en `src/assets/` y se referencia por URL desde un `<img>`, no como componente inline. |

Ambos archivos son originales del proyecto: el dither se generó a partir de una fotografía propia y el lockup es la marca del grupo.

**Tipografía:** Archivo, de Google Fonts. Cargar `@300;400;500;600;800` desde `index.html` o, mejor para performance y para no depender de un tercero, servirla self-hosted con `@font-face` y `font-display: swap`.

## Files

| Archivo | Contenido |
|---|---|
| `login-7g.html` | La pantalla completa, autónoma, abrible en el navegador. Fuente de verdad visual. |
| `assets/mtn-teal-cutout.png` | Cordillera. |
| `assets/arbiter-lockup.svg` | Lockup. |

En el proyecto de diseño la variante vive en `Arbiter Login.dc.html`, con el id `7g` (hay otras variantes al lado: fondo azul noche, lockup en esquina, cordillera ampliada; ninguna es la elegida).

## Checklist de implementación

- [ ] Definir el color de acento (ver "Decisión pendiente").
- [ ] Definir Universal Login vs. login embebido con Auth0.
- [ ] Definir el destino de `Solicitar acceso`.
- [ ] `LoginComponent` con Reactive Forms y SCSS propio.
- [ ] Estados: focus, hover, error de campo, error de autenticación, loading.
- [ ] Responsive con el breakpoint de 768 px y objetivos táctiles de 48 px.
- [ ] Accesibilidad: `<label for>` real en cada input, `autocomplete="email"` y `autocomplete="current-password"`, mensajes de error asociados con `aria-describedby`, `aria-live="polite"` en el error de autenticación, foco visible en todos los interactivos.
- [ ] La cordillera es decorativa: `alt=""` y `aria-hidden="true"`.
